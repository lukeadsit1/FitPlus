package com.example.fitplusbasev1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button calcButton = (Button)findViewById(R.id.calculator);
        calcButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToCalculator();
            }
        });
        Button trackButton = (Button)findViewById(R.id.tracker);
        trackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToTracker();
            }
        });
        Button planButton = (Button)findViewById(R.id.fitnessplan);
        planButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToPlan();
            }
        });
    }
    private void goToCalculator(){
        Intent intent = new Intent(this, BMICalculator.class);
        startActivity(intent);
    }
    private void goToTracker(){
        Intent intent = new Intent(this, BMITracker.class);
        startActivity(intent);
    }
    private void goToPlan(){
        Intent intent = new Intent(this, FitnessPlan.class);
        startActivity(intent);
    }
}
