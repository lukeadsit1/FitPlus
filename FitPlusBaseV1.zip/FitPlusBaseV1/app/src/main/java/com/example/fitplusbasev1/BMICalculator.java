package com.example.fitplusbasev1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class BMICalculator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b_m_i_calculator);

        Button menuButton = (Button)findViewById(R.id.menu);
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToMenu();
            }
        });
        Button calcButton = (Button)findViewById(R.id.calcButton);
        calcButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcBMI();
            }
        });
    }

    private void goToMenu(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    private void calcBMI(){
        EditText heightValue = findViewById(R.id.heightBox);
        double height = Integer.parseInt(heightValue.getText().toString());

        EditText weightValue = findViewById(R.id.weightBox);
        double weight = Integer.parseInt(weightValue.getText().toString());

        double bmi = ((weight*703)/(height*height));

        EditText bmiValue = findViewById(R.id.bmiBox);
        bmiValue.setText(String.format("%.2f",bmi));

    }
}
