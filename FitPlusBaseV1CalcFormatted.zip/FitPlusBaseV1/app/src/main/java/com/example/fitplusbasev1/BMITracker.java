package com.example.fitplusbasev1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BMITracker extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b_m_i_tracker);
    }
}
